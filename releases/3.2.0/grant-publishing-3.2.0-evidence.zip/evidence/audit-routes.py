from pathlib import Path
from lxml import html
import json,re,hashlib
root=Path('/workspace/grant-publishing-codex-handoff/deliverables/grant-publishing-site');before=Path('/workspace/grant-baseline/grant-publishing-site');defs=json.loads((root/'pages.json').read_text())
def route(k):
 d=defs[k];return ('/'+defs[d['parent']]['slug'] if d.get('parent') else '')+'/'+d['slug']+'/' if k!='home' else '/'
paths={route(k):k for k in defs};report=[]
for k in defs:
 raw=(root/'templates'/f'{k}.html').read_text();old=(before/'templates'/f'{k}.html').read_text();assert html.fromstring(raw).text_content()==html.fromstring(old).text_content(),(k,'copy changed')
 assert [e.tag for e in html.fromstring(raw).xpath('//h1|//h2|//h3')]==[e.tag for e in html.fromstring(old).xpath('//h1|//h2|//h3')],k
 doc=html.fromstring(Path('/workspace/grant-qa/fixtures/after',k+'-fallback.html').read_text())
 actions=[]
 from urllib.parse import urlsplit,parse_qs
 for a in doc.xpath('//a'):
  href=a.get('href');assert href and not href.startswith('javascript:') and href!='#',(k,href)
  parsed=urlsplit(href)
  if not parsed.scheme:
   if parsed.path:assert parsed.path in paths,(k,href)
   if parsed.fragment:
    dest=paths.get(parsed.path,k);target=html.fromstring(Path('/workspace/grant-qa/fixtures/after',dest+'-fallback.html').read_text());assert target.xpath('//*[@id=$id]',id=parsed.fragment),(k,href)
  actions.append({'label':a.text_content().strip() or a.get('aria-label'),'href':href})
 report.append({'page':k,'route':route(k),'actions':actions,'forms':len(doc.xpath('//form'))})
 for asset in ['grant-logo.png','abdulqudus-tella.png','kathryns-beach.jpg']:
  assert (root/'assets'/asset).read_bytes()==(before/'assets'/asset).read_bytes(),asset
assert (root/'pages.json').read_bytes()==(before/'pages.json').read_bytes()
Path('/workspace/grant-deliverables/evidence/route-action-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: all 17 routes; '+str(sum(len(x['actions']) for x in report))+' rendered internal/external action records; internal destinations/anchors valid; page copy, heading hierarchy, route definitions and supplied assets preserved. External URLs recorded, not network-verified.')
